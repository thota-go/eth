var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
var MongoClient = require('mongodb').MongoClient;
var callback = require('callback');
var url = 'mongodb://localhost:27017/mydb';

var Web3 = require('web3');
var contract = require('truffle-contract');
user_artifacts = require('../contracts/User.json');

const ipfsAPI = require('ipfs-api');
const ipfs = ipfsAPI('localhost', '5001');

// User is our usable abstraction, which we'll use through the code below.
var User = contract(user_artifacts);

let accounts
let account
let newAcc
let passwrd

let web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
User.setProvider(web3.currentProvider);
/////////////////////////////////////////////////////////////////////////////////////////////
module.exports = (function (app) {
    app.get('/', function (req, res) {
        res.render('home');
    });
    app.get('/register', function (req, res) {
        res.render('register');
    });
    app.get('/login', function (req, res) {
        res.render('login');
    });
    app.get('/upload', function (req, res) {
        res.render('upload');
    });
    // Login TO DB==================================================================
    app.post('/demo', urlencodedParser, function (req, res) {
        MongoClient.connect(url, function (err, db) {
            db.collection('userprofile').findOne({ name: req.body.name }, function (err, user) {
                if (user === null) {
                    res.end("Login invalid");
                } else if (user.name === req.body.name && user.pass === req.body.pass) {
                    res.render('completeprofile', { profileData: user });
                } else {
                    console.log("Credentials wrong");
                    res.end("Login invalid");
                }
            });
        });
    });
    //register to DB================================================================
    app.post('/regiterToDb', urlencodedParser, function (req, res) {
        var obj = JSON.stringify(req.body);
        var jsonObj = JSON.parse(obj);
        res.render('profile', { loginData: req.body });

    });
    //register profile to MongoDB================================================================
    app.post('/completeprofile', urlencodedParser, function (req, res) {
        var obj = JSON.stringify(req.body);
        console.log("Final reg Data : " + obj);
        var jsonObj = JSON.parse(obj);
        MongoClient.connect(url, function (err, db) {
            db.collection("userprofile").insertOne(jsonObj, function (err, res) {
                if (err) throw err;
                console.log("1 document inserted");
                //db.close();
            });
            //Create Ethereum account
            passwrd = req.body.pass;
            const createNewUser = async (callback) => {
                try {
                    //console.log("Password" + passwrd);
                    const userInfo = await web3.personal.newAccount(passwrd, function (err, res) {
                        if (!err)
                            console.log("New Account: " + res);
                        else
                            console.log("error: " + err);
                        newAcc = res;
                        web3.personal.unlockAccount(newAcc, passwrd, 15000);
                        //update user profiles table with user ethereum account details.
                        db.collection("userprofile").update({ "name": req.body.name }, { $set: { "ethid": newAcc, "ipfsimgid": [] } }, function (err, res) {
                            if (err) throw err;
                            console.log("1 document updated");
                            db.close();
                        });
                        //end db table update
                        return callback(null, newAcc);
                    });
                } catch (e) {
                    console.log(e);
                }
            };

            createNewUser(function (err, newac) { //err = null, newac = newAcc
                const assignEtherToUser = async (callback) => {
                    try {
                        const fund = await web3.eth.sendTransaction({
                            from: "0xC8848619608bc461Bb2C4B88bbF85dA169cfA35A",
                            to: newac,
                            value: web3.toWei(100, "ether")
                        }, function (err, transactionHash) {
                            if (!err)
                                console.log("Transaction hash########", transactionHash);
                            return callback(null, transactionHash);
                        });

                    } catch (e) {
                        console.log(e);
                    }
                };

                assignEtherToUser(function (err, txhash) {
                    //Add entries into IPFS
                    ipfs.add([Buffer.from(JSON.stringify(req.body))], function (err, res) {
                        if (err) throw err
                        ipfsHash = res[0].hash
                        console.log('Creating user::', req.body.name, ' on eth');
                        //console.log("User created for Account No:", newAcc);
                        console.log("IPFS hash for User:", ipfsHash);
                        User.deployed().then(function (contractInstance) {
                            contractInstance.createUser(req.body.name, ipfsHash, { gas: 200000, from: newAcc }).then(function (success) {
                                if (success) {
                                    console.log('created user on ethereum!');
                                } else {
                                    console.log('error creating user on ethereum');
                                }
                            }).catch(function (e) {
                                // There was an error! Handle it.
                                console.log('error creating user:', req.body.name, ':', e);
                            });
                        });
                    });

                });
            });

            res.render('completeprofile', { profileData: req.body });
        });
    });
    //upload docs================================================================
    app.post('/uploaddocs', urlencodedParser, function (req, res) {
        var obj = JSON.stringify(req.body);
        var jsonObj = JSON.parse(obj);

        userName = req.body.uname;
        console.log(userName);

        res.render('upload', { uploadData: req.body });

    });

    //upload docs================================================================
    app.post('/uploadmongo', urlencodedParser, function (req, res) {

        console.log(req.body);
        username = req.body.uname;
        url1 = req.body.ipfsurl;
        ipfshash = req.body.ipfshash;

        console.log(username, " : ", url1, " : ", ipfshash);

        //commit user, ipfs hash of image into blockchain.

        User.deployed().then(function (contractInstance) {
            contractInstance.createUser(username, ipfshash, { gas: 200000, from: newAcc }).then(function (success) {
//var count = web3.eth.getBlockTransactionCount("pending");
//console.log(count);
                if (success) {
                    console.log('created image reference hash on ethereum!');

                    /////Start - Capture transaction details


var contractAddress = "0x6AC56098c173447861886619b7788d14637db7b7";
var walletAdd = "0xC8848619608bc461Bb2C4B88bbF85dA169cfA35A";
var filter = web3.eth.filter({fromBlock: 9000, toBlock: web3.eth.getBlock('latest'), address: "{0x6AC56098c173447861886619b7788d14637db7b7}"});
filter.get(function (error, result) {
 if (!error)
    console.log(JSON.stringify(result, null, 2));
});
filter.stopWatching();
                    ///////End - Capture transaction details
                } else {
                    console.log('error creating image reference hash on ethereum');
                }
            }).catch(function (e) {
                // There was an error! Handle it.
                console.log('error creating image reference hash:', ipfshash, ':', e);
            });
        });

        // Insert ipfs url into mongo db.
        MongoClient.connect(url, function (err, db) {
            db.collection("userprofile").update({ "name": username }, { $addToSet: { "ipfsimgid": url1 } }, function (err, res) {
                if (err) throw err;
                console.log("1 document inserted");
                db.close();
            })
        });
    });

});

