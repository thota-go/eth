To run this app, 
>node app.js
